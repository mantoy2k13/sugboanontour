
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/logo.f5060116.png')); ?>" style="width:220px;height:100px;"></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
			

	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="<?php echo e(url('/')); ?>" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="<?php echo e(url('hotels')); ?>" class="nav-link ">Hotels</a></li>
	          <li class="nav-item"><a href="#" class="nav-link ">Services</a></li>
			  <li class="nav-item"><a href="<?php echo e(url('contact')); ?>" class="nav-link ">Contact</a></li>
	          <li class="nav-item"><a href="<?php echo e(url('findcars')); ?>" class="nav-link ">Find Cars</a></li>
	          <li class="nav-item"><a href="tel:+63915 097 1513" class='nav-link'><span class="icon-mobile-phone"></span> 0915 097 1513</a> </li>
			  
			  <?php if(Auth::check()): ?>
			  <li class="nav-item">
				<a class="nav-link " href="<?php echo e(url('dashboard')); ?>" >Dashboard</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link " href="<?php echo e(route('signout')); ?>" >Logout</a>
			  </li>

			  <?php else: ?>

			  <li class="nav-item">
				  <a class="nav-link"  href="<?php echo e(route('login')); ?>">Login</a>
			  </li>

			  <?php endif; ?>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->


	<?php /**PATH C:\xampp\htdocs\sugboanontour\resources\views/partials/header.blade.php ENDPATH**/ ?>