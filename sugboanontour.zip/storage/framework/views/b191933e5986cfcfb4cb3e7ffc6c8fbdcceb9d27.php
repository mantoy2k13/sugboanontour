
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="py-5" >&nbsp;</div>
        <div class="row justify-content-center mb-5">
          <div class="col-md-4 heading-section text-center ftco-animate">
             <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
          	<span class="subheading text-default">Add cars</span>    
                <?php
                    if (Auth::check()) {
                        $id = Auth::user()->id;
                    }
                    else{
                        $id = 0;
                    }
                ?>
                
          </div>
        </div>
        <div class="row d-flex">
           <form  method="post"  action="<?php echo e(url('cars-store')); ?>"  enctype="multipart/form-data" class="bg-light p-5 contact-form">
            <?php echo e(method_field('POST')); ?>

          <?php echo csrf_field(); ?>
            <div class="row"> 

                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                        <input type="text" name="vehicle_name" placeholder="Make Vehicle " class="form-control">
                    </div>
                    <?php $__errorArgs = ['vehicle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 col-lg-6 "><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
              <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                        <input type="file" name="filenames[]" placeholder="Choose image" multiple class="form-control">
                    </div>
                    <?php $__errorArgs = ['filenames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 col-lg-6 "><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                        <input type="text" name="model" placeholder="Model Name" class="form-control" >
                    </div>
                    <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 col-lg-6 "><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- end for model -->

                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                        <input type="year" name="year" placeholder="Year" class="form-control" >
                    </div>
                    <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 col-lg-6 "><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- end for date type-->

                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                        <input type="text" name="location" placeholder="Location address" class="form-control" >
                    </div>
                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 col-lg-6 "><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                        <input type="text" class="form-control" name ="book_date" placeholder="Rate"  /> <!-- temporary rate -->
                    </div>
                    <?php $__errorArgs = ['book_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 col-lg-6"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                  <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                        
                        <select name="vehicle_type" class="form-control"  id="">
                            <option value="">  Please select vehicle type  </option>
                            <option value="sedan"> Sedan</option>
                            <option value="suv"> SUV</option>
                            <option value="van"> Van</option>
                            <option value="hatchback">Hatchback</option>
                            <option value="crossover">Cross Over</option>
                        </select>
                    </div>
                    <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 col-lg-6"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <input type="hidden" name='user_id' value="<?php echo e($id); ?>">    
                <div class="col-md-6 col-lg-12">
                    <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                </div>
            </div>     
            
        </form>
       
    <!-- 2000 56095 787 promisory note-->
        </div>
      </div>
      <?php $__env->startPush('head'); ?>
<!-- Styles -->


<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sugboanontour\resources\views/pages/carsajax.blade.php ENDPATH**/ ?>