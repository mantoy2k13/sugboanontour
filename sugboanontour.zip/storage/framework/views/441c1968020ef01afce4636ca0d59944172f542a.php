
<?php $__env->startSection('content'); ?>
<?php 
$imgs = json_decode($trpackage->name, true);
$tourpackage = ($trpackage->id) ? $trpackage->id : 0 ;
?>
<div class="container mt-5">

<section class="ftco-section ftco-degree-bg">
      <div class="container">
        <div class="row">
            

          <div class="col-md-8 ftco-animate">
            <h2 class="mb-3 orange"><?php echo e($trpackage->title); ?> </h2>
            <?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(asset('files/'.$image)); ?>" alt="" class="img-fluid mt-3">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <!-- end loop for images-->
          

          </div> <!-- .col-md-8 -->
          <div class="col-md-4 sidebar ftco-animate">
            <div class="sidebar-box ftco-animate">
              <div class="categories">
                <h3 class="orange">Call: <a href="tel:+63915 097 1513" class="orange"> 0915 097 1513</a> </h3>
                <?php echo $trpackage->details; ?>

                <h3 class="mb-3"> </h3>
              </div>
            </div>
            <div class="sidebar-box ftco-animate">
              <div class="comment-form-wrap ">
                <h3 class="mb-5">Book now</h3>
                <form method="POST" action="<?php echo e(url('booknow')); ?>" class=" bg-light">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="name">Name *</label>
                    <input type="text" name="name"class="form-control" id="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 "><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" name="email" class="form-control" id="email">
                  </div>
                  <div class="form-group">
                    <label for="contact">Contact Number *</label>
                    <input type="text" name="contact_number" class="form-control" id="contact_number">
                    <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1 "><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group">
                    <label for="contact">Contact Number *</label>
                    <input type="text" name="contact_number" class="form-control" id="name">
                  </div>
                  <div class="form-group">
                    <label for="message">Message</label>
                    <textarea name="message" id="message" cols="30" rows="10" class="form-control"></textarea>
                  </div>
                  <div class="form-group">
                    <input type="hidden" name="tourpackage" value="<?php echo e($tourpackage); ?>">
                    <input type="submit" value="Book" class="btn py-3 px-4 btn-primary">
                  </div>

                </form>
              </div>
            </div>
        </div>
      </div>
    </section> <!-- .section -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sugboanontour\resources\views/pages/tourpackage.blade.php ENDPATH**/ ?>