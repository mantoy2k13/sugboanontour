<link rel="stylesheet" href="<?php echo e(asset('css/open-iconic-bootstrap.min.css')); ?> ">
<link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?> ">
<link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?> ">

<link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?> ">

<link rel="stylesheet" href="<?php echo e(asset('css/ionicons.min.css')); ?> ">

<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/jquery.timepicker.css')); ?> ">


<link rel="stylesheet" href="<?php echo e(asset('css/flaticon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/icomoon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.11.0/sweetalert2.css" />
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>"> 
<?php /**PATH C:\xampp\htdocs\sugboanontour\resources\views/partials/styles.blade.php ENDPATH**/ ?>