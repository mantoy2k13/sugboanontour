
<?php $__env->startSection('content'); ?>
	<section class="ftco-section ftco-cart">

		<div class="container py-5">
			<div class="row">
				<?php 
										$id = (Auth::check()) ? Auth::user()->id : 0;
	$name = (Auth::check()) ? Auth::user()->name : 'Juan Dela Cruaz';
									?>
				<div class="col-md-4">
					<span class='messagealert text-success' id="success"></span>
				</div>
				<?php if(session('success')): ?>
					<div class="col-md-8 ">
						<div class='alert alert-success'>
							<p class='text-default'><?php echo e(session('success')); ?></p>
						</div>
					</div>
				<?php endif; ?>
				<span class='flex'>
					<a href="<?php echo e(url('/cars')); ?>" class="btn btn-primary"> Add Cars</a>
				</span>
			</div>
			<div>
				<h3 class='text-black'>Welcome,
					<span class='text-default text-lg'> <?php echo e($name); ?> </span>
				</h3>
			</div>

		</div>
		<!-- #region -->
	</section>


	<section class="ftco-section bg-light">

		<div class="container">
			<div class="row">

				<?php if(count($cars) > 0): ?>

					<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keycar => $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$car_img = json_decode($car->img, true);
							if ($car->book_status == 1) {
								$message_available = 'Your car is Available';
								$text_color = 'text-white';
							} else {
								$message_available = 'Your car is Booked';
								$text_color = 'text-danger';
							}							
						?>
						<div class="col-md-4" id="car<?php echo e($car->id); ?>">
							<div class="car-wrap rounded ftco-animate">
								<div class="img rounded d-flex align-items-end"
									style="background-image: url('<?php echo e(asset('files/' . $car_img[0])); ?>');">
									<h3 class='available font-weight-bolder <?php echo e($text_color); ?>'><?php echo e($message_available); ?></h3>
								</div>
								<div class="text">
									<h2 class="mb-0 text-default"><a href="car-single.html" class='text-default'><?php echo e($car->name); ?> <?php echo e($car->model); ?> </a>
									</h2>
								
									<div class='d-flex mb-2'>
										<a href="javascript:void(0)" class="btn btn-danger"
											onclick="cardelete(<?php echo e($car->id); ?>)"><i class="icomoon icon-remove"></i></a>
										<i class="fa fa-edit"></i>
										<a href="<?php echo e(url('/cars/edit/'.$car->id)); ?>" class='btn btn-success'><i class="icomoon icon-undo"></i> Edit</a>
									</div>
										
											<button role="button" class="btn btn-secondary py-2 ml-1"
											onclick="setavailable(<?php echo e($car->id); ?>, 1)">
											 Set to avaiable

										</button>
										<button role="button" class="btn btn-secondary py-2 ml-1"
											onclick="setavailable(<?php echo e($car->id); ?>, 2)">
											Set to NOT AVAILABLE
										</button>

									
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>

					<h3 class="text-default">
						you dont have yet uploaded cars,.. please add car,
					</h3>

				<?php endif; ?>

			</div>

		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

	<script type="text/javascript">

		var adminUrl = "<?php echo e(url('/')); ?>";

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldContent('script'); ?>
<?php $__env->startPush('head'); ?>


	<!-- Scripts -->

	<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sugboanontour\resources\views/auth/dashboard.blade.php ENDPATH**/ ?>