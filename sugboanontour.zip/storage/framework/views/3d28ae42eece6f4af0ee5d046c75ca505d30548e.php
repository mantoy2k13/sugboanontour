
<?php $__env->startSection('content'); ?>

	<section class="ftco-section bg-light">
		
		<div class="container">
			<div class="row">
					<?php if(session('success')): ?>
					<div class="col-md-12 d-flex ">
						<div class="alert alert-success" role="alert">
							<p class='text-black'><?php echo e(session('success')); ?></p>
						</div>
					</div>
				<?php endif; ?>
				<?php if(count($findcars) > 0): ?>

					<?php $__currentLoopData = $findcars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keycar => $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php 
										$car_img = json_decode($car->img, true);
						if ($car->book_status == 1) {
							$message_available = 'Available';
							$text_color = 'text-white';
						} else {
							$message_available = 'Booked';
							$text_color = 'text-danger';
						}
						$book_url = url('vehicle/' . $car->id);
										?>

							<div class="col-md-4" id="car<?php echo e($car->id); ?>">
								<div class="car-wrap rounded ftco-animate">
									<div class="img rounded d-flex align-items-end"
										style="background-image: url('<?php echo e(asset('files/' . $car_img[0])); ?>');">
										<h3 class='available font-weight-bolder <?php echo e($text_color); ?>'><?php echo e($message_available); ?></h3>
									</div>
									<div class="text">
										<h2 class="mb-0 text-default"><a href="car-single.html" class='text-default'><?php echo e($car->name); ?>

												<?php echo e($car->model); ?> </a></h2>
										<div class="d-flex flex-column  mb-3">
											<p class="font-weight-bolder"> Rate: <?php echo e($car->rate); ?> <span class='font-weight-light'> /
													day</span></p>
											<p class='text-black'><span class="icon-map-o"></span>
												<?php echo e(strtoupper($car->location)); ?>

											</p>
											<p class='text-black'><span class="flaticon-car-seat"></span> 5 seats adult</p>

										</div>
										<p class="d-flex mb-0 d-block"><a href="<?php echo e($book_url); ?>" class="btn btn-secondary py-2 ml-1">Book
												now</a>

										</p>
									</div>
								</div>
							</div>


					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>

					<h3 class="text-default">
						No available as of moment, Congrats fullybook!
					</h3>

				<?php endif; ?>

			</div>

		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>


	<!-- Scripts -->

	<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sugboanontour\resources\views/pages/findcars.blade.php ENDPATH**/ ?>