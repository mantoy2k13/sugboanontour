<!DOCTYPE html>
<html lang="en">
<head>
  <!-- 
    ** Author: Daryl Bargamento **
    ** Application: PHP Laravel **
    ** Jquery framework **
    ** CSS flex bootstrap **
  -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Daryl Bargamento">
  <meta http-equiv="Permissions-Policy" content="interest-cohort=()">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title> <?php echo e($title = ($title) ? $title : 'Cebu Car Bnb rentals'); ?></title>

  <?php echo $__env->make('partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
</body>
</html><?php /**PATH C:\xampp\htdocs\sugboanontour\resources\views/layouts/master.blade.php ENDPATH**/ ?>